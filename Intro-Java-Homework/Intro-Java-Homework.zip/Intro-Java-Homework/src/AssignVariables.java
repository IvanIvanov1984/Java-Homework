public class AssignVariables {
    public static void main(String[] args) {
        boolean someBoolean = false;
        String someString = "Palo Alto, CA";
        short someShort = 32767;
        int someInt = 2000000000;
        double someDouble = 0.1234567891011;
        float someFloat = 0.5f;
        long someLong = 919827112351L;
        byte someByte = 127;
        char someChar = 'c';
//        short someShort2 = 32768; Извън обхвата е.
    }
}