public class PrintCharacters {
    public static void main(String[] args) {
        for (char c = 'a'; c < 123; c += 1) {
            System.out.print(c + " ");
        }
    }
}